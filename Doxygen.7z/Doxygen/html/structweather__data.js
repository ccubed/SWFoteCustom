var structweather__data =
[
    [ "change", "structweather__data.html#a2a76f35c40fd46f1c02adf10b002070b", null ],
    [ "mmhg", "structweather__data.html#a9c8b22431345e6edf1ff9bb3d02215a4", null ],
    [ "sky", "structweather__data.html#a59e908958e697d88c176d0e3474e46c3", null ],
    [ "sunlight", "structweather__data.html#a9ab25d9057a1923217380ca0f9d4e4a2", null ]
];