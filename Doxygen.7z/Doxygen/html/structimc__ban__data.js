var structimc__ban__data =
[
    [ "name", "structimc__ban__data.html#a319ff6131f2b436939f5c68fe2a1b639", null ],
    [ "next", "structimc__ban__data.html#ae11e00404956c9c7226e1b9523bfcd54", null ],
    [ "prev", "structimc__ban__data.html#ab46bd78404ce27cb1fbe3abb48858314", null ]
];