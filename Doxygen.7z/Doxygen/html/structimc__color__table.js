var structimc__color__table =
[
    [ "imctag", "structimc__color__table.html#aef7653a803ce38e1a95f3a25d7946df0", null ],
    [ "mudtag", "structimc__color__table.html#a561edace33fd6959a76ae4dcf9bfd12e", null ],
    [ "name", "structimc__color__table.html#a0e36a16b238d8f9ff5673783dad62f2c", null ],
    [ "next", "structimc__color__table.html#ad991a67de839b8fd08e411c913fba524", null ],
    [ "prev", "structimc__color__table.html#a10d25361af4a29b0ce9114db78417063", null ]
];