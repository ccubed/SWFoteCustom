var structwis__app__type =
[
    [ "practice", "structwis__app__type.html#a258d93831e52f401b0f1125d2c9b746e", null ]
];