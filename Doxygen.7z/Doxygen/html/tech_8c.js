var tech_8c =
[
    [ "do_makemodule", "tech_8c.html#a9a0bb1a7d8fcfb9bb644c7e96dc0d4a7", null ],
    [ "do_removebug", "tech_8c.html#a14ad43e1be05152ddcee667c7dc3ecd0", null ],
    [ "do_removemodule", "tech_8c.html#a31320b8ffa8d3c96eafd07173d1ca21b", null ],
    [ "do_scanbugs", "tech_8c.html#a9d36e639bc52a77738907e29540437d2", null ],
    [ "do_shipmaintenance", "tech_8c.html#a4f2403c45f09b05765ec4c1cc0f7876d", null ],
    [ "do_showmodules", "tech_8c.html#adaa88949f062b80b03f114319a75fa7d", null ]
];