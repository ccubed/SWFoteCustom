var structsmaug__affect =
[
    [ "bitvector", "structsmaug__affect.html#ac022ca99022c2671de52fe36d3e4db97", null ],
    [ "duration", "structsmaug__affect.html#a4337675b7e17e03938dc93ec24de5074", null ],
    [ "location", "structsmaug__affect.html#ada0aaea271a0b08bea0ce268b8c8b5e0", null ],
    [ "modifier", "structsmaug__affect.html#ab4016338d4bee7ece5f9e71c0924b581", null ],
    [ "next", "structsmaug__affect.html#a7c73a71b431d6a14829293306c59b1ec", null ]
];