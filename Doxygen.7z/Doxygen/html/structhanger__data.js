var structhanger__data =
[
    [ "bayopen", "structhanger__data.html#a50e545b1a54b243501195b4b9411c51b", null ],
    [ "next", "structhanger__data.html#af92dcd77cec94db3f55783433a295325", null ],
    [ "prev", "structhanger__data.html#a328aaeb3d5391ee154c48f3c3fa98bcf", null ],
    [ "room", "structhanger__data.html#a02024a8a440e37fed8466d9802a9fb0b", null ],
    [ "type", "structhanger__data.html#a46cec8053fe59d8d20c1e666250adb4c", null ]
];