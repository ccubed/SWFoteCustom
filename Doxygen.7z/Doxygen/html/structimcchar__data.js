var structimcchar__data =
[
    [ "aim", "structimcchar__data.html#abbdc04d861b7598a3506fc76fbd6dcf8", null ],
    [ "comment", "structimcchar__data.html#ab05c0fd53b80869665af251766953c89", null ],
    [ "email", "structimcchar__data.html#a13b017b8870d35f9a577adb10dfd693a", null ],
    [ "homepage", "structimcchar__data.html#ac0b2c939310d7a80db7f28a748031f3e", null ],
    [ "icq", "structimcchar__data.html#a798169e8f74bd6bc7ceddbd958a78fc1", null ],
    [ "imc_denied", "structimcchar__data.html#a2ae330af649ea78c3524e3635ed7aa40", null ],
    [ "imc_listen", "structimcchar__data.html#a32520c9ce46ee7ce9fadc6e7d2362464", null ],
    [ "imc_tellhistory", "structimcchar__data.html#a7f871fd264c805a520d8607fbfab6d56", null ],
    [ "imcfirst_ignore", "structimcchar__data.html#a66311f49346fd131c95e5f254c8f1a27", null ],
    [ "imcflag", "structimcchar__data.html#a03862511b6a05de110f4f2cad4cfe08d", null ],
    [ "imclast_ignore", "structimcchar__data.html#a38f630abd5e7f6bc4d993570092e828e", null ],
    [ "imcperm", "structimcchar__data.html#a22031b06e9745987450b310301d5afe2", null ],
    [ "msn", "structimcchar__data.html#a1af59a2cf8cbc6dc9b7b0214f3d6b164", null ],
    [ "rreply", "structimcchar__data.html#aa06791dc4c16d26f65a45257c2e49dd5", null ],
    [ "rreply_name", "structimcchar__data.html#a32489b1a775b5ca6c99815747bda77ff", null ],
    [ "yahoo", "structimcchar__data.html#abeaa83dc82902250b13061dd522b4580", null ]
];