var structtime__info__data =
[
    [ "day", "structtime__info__data.html#a1f01632ffda7d65eac96af317c583314", null ],
    [ "hour", "structtime__info__data.html#a0fcbcda81b3ab0a49d32a41744b137d9", null ],
    [ "month", "structtime__info__data.html#a22108b21961f4f9cec8b54a4b4c4d84d", null ],
    [ "year", "structtime__info__data.html#a9b23c77bd71d154d663750877835b09a", null ]
];