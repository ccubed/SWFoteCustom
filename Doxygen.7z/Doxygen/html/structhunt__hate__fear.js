var structhunt__hate__fear =
[
    [ "name", "structhunt__hate__fear.html#a6ca475a190eb0ed40abd52e909b36460", null ],
    [ "who", "structhunt__hate__fear.html#a462de348aab37ea14828fdd8bb7489ed", null ]
];