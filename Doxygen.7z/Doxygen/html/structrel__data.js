var structrel__data =
[
    [ "Actor", "structrel__data.html#ac5d81544b2e98ceea53bc7d9e80c1bdd", null ],
    [ "next", "structrel__data.html#a0629f68f4cad041f799fe384a73c538f", null ],
    [ "prev", "structrel__data.html#aad988053e33f87216da464e5300f50f3", null ],
    [ "Subject", "structrel__data.html#ab5f1bb96df49692a7ccd6e1dbc9c8f87", null ],
    [ "Type", "structrel__data.html#a505d4f5529736fcae6eaa9e65872be2f", null ]
];