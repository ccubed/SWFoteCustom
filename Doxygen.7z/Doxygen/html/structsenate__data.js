var structsenate__data =
[
    [ "name", "structsenate__data.html#ae7538c0a90c154f5db941421d2c08006", null ],
    [ "next", "structsenate__data.html#aa51f5b25b7acb097ea3cd7282087a596", null ],
    [ "prev", "structsenate__data.html#a92da0447e1d4c2047147335bf5acb2af", null ]
];