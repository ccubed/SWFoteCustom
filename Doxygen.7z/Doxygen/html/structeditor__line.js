var structeditor__line =
[
    [ "line", "structeditor__line.html#a487ce9abeaf6f28f35372c3f2c1d9872", null ],
    [ "line_size", "structeditor__line.html#aaafcdf768ec9905c96c4e080bec1396e", null ],
    [ "line_used", "structeditor__line.html#a25a76e3344994107160400e23e669296", null ],
    [ "next", "structeditor__line.html#a150f6c474fc2cb39842927f841140bee", null ]
];