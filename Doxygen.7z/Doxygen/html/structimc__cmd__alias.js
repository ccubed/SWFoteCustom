var structimc__cmd__alias =
[
    [ "name", "structimc__cmd__alias.html#a59bdc1236e43b62284e76d1ba4ad3c3a", null ],
    [ "next", "structimc__cmd__alias.html#aec9c90e452aea01fe59895a842526984", null ],
    [ "prev", "structimc__cmd__alias.html#a4321d6b6d0102672869dc58899caf272", null ]
];