var structtourney__data =
[
    [ "hi_level", "structtourney__data.html#a27ded05e688074e383e6b65cf399aa0a", null ],
    [ "low_level", "structtourney__data.html#aa13d10329c4b584e890930b98de35457", null ],
    [ "open", "structtourney__data.html#aa3b9c320bb6c30457c155f1db4a2f6b8", null ]
];