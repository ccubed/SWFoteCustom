var structfellow__data =
[
    [ "knownas", "structfellow__data.html#a63f4e318500844aae3aff2fe5404296a", null ],
    [ "next", "structfellow__data.html#ab6669f9bc4b956544592c2591785e190", null ],
    [ "prev", "structfellow__data.html#a01cd88b16bdf2558f937b391c8f58dcf", null ],
    [ "victim", "structfellow__data.html#a50da7c766f72a84e11285d42ab87a3f9", null ]
];