var structcha__app__type =
[
    [ "charm", "structcha__app__type.html#a15083a5171ddc273e8ee9e7ef32425aa", null ]
];