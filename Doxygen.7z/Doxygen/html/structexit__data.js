var structexit__data =
[
    [ "description", "structexit__data.html#ab2d823b37978933e123a5ed6f48244e6", null ],
    [ "distance", "structexit__data.html#ada6fa32ae67eb745dda402620b76423b", null ],
    [ "exit_info", "structexit__data.html#adcadd67019443935c6d312b17e4e6492", null ],
    [ "key", "structexit__data.html#a2ef6121c255eaad4461de21d1fa9376e", null ],
    [ "keyword", "structexit__data.html#a4ba3907364f827dd950a4eea017e1705", null ],
    [ "next", "structexit__data.html#aa8fdd7eedf8996d6066cf281a83f07fb", null ],
    [ "prev", "structexit__data.html#a3a5f1fe587285391c03a102e2e743089", null ],
    [ "rexit", "structexit__data.html#aaccc91edd631623813fb51a17df7ee00", null ],
    [ "rvnum", "structexit__data.html#a3040d932a5ce1d6b64e361784eb246f1", null ],
    [ "to_room", "structexit__data.html#a6a0b9530e162151fe955ff59595c727f", null ],
    [ "vdir", "structexit__data.html#a40cab7fd9c7f3d23eb829a39888b39e6", null ],
    [ "vnum", "structexit__data.html#a98e33947988ea9ce9f2fd39d003c790b", null ]
];