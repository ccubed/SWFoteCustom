var structkilled__data =
[
    [ "count", "structkilled__data.html#a347a9b0f5843c95c2c09fe7faa398142", null ],
    [ "vnum", "structkilled__data.html#a66a74a09dceb3f52162c94c22ce5d743", null ]
];