var structblackmarket__data =
[
    [ "filename", "structblackmarket__data.html#a6e1e75fb5f4ce7fbea159d0cb0cee61f", null ],
    [ "next", "structblackmarket__data.html#a7ed427b3ce75296b4646dcf0b5a0670b", null ],
    [ "prev", "structblackmarket__data.html#afe28aa5db8f99c20e281fb5b71f4a575", null ],
    [ "quantity", "structblackmarket__data.html#a556dd254a769a32c2c8e1b99a27b0125", null ]
];