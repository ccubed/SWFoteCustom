var structfighting__data =
[
    [ "align", "structfighting__data.html#abba640a431efab3a494e764cb06bba4f", null ],
    [ "duration", "structfighting__data.html#a2cb1ddeea05f12649c75b5a7c236b2cf", null ],
    [ "timeskilled", "structfighting__data.html#a995b53ea3c83d3c4caef5aac37033410", null ],
    [ "who", "structfighting__data.html#a73b6d75e8c276d078fca4a8665c709df", null ],
    [ "xp", "structfighting__data.html#a792227d341fea77ae52f477f854828bc", null ]
];