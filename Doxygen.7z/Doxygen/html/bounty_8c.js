var bounty_8c =
[
    [ "args", "bounty_8c.html#a1f45dcbf259956351b6086e61568fc34", null ],
    [ "claim_disintegration", "bounty_8c.html#add96e39948e784658c67d493ba523f18", null ],
    [ "disintegration", "bounty_8c.html#a68e8254cb35653cd3739230c6c32f599", null ],
    [ "do_addbounty", "bounty_8c.html#a73e918386efe6790792ec3821c12c6f5", null ],
    [ "do_bounties", "bounty_8c.html#a6befa1e556cf48613688d63f4854e06d", null ],
    [ "do_rembounty", "bounty_8c.html#af21ca594b78857b890ccca6afab186a7", null ],
    [ "get_disintegration", "bounty_8c.html#aee9dcd9cf3823c0c6248488ce82359ed", null ],
    [ "is_disintegration", "bounty_8c.html#a0ec800b8be76169eb88f60e7b3116e87", null ],
    [ "load_bounties", "bounty_8c.html#a59b51cd43e8d3b10970bdc5c9b0c61d2", null ],
    [ "remove_disintegration", "bounty_8c.html#a92d52e9433cf4728592ae7c6e54652c6", null ],
    [ "save_disintegrations", "bounty_8c.html#ac7e94ac9436ac0b2fe409945f0f38a86", null ],
    [ "xp_compute", "bounty_8c.html#ab94d100ae4215e7f925e9e2c2df6c51d", null ],
    [ "first_bounty", "bounty_8c.html#a83b9efe58fa31e77d9d7e5a3d3774f8f", null ],
    [ "first_disintegration", "bounty_8c.html#a059a4fbf0852ae7ccae95005c5425a8c", null ],
    [ "last_bounty", "bounty_8c.html#a0ae6e2770e15c78e934dc39341d69b33", null ],
    [ "last_disintegration", "bounty_8c.html#a5edeb4df9d207993f095c0e2470f6a12", null ]
];