var structcompanion__classes =
[
    [ "primary_class", "structcompanion__classes.html#af9ddd964c264a8f459476677925f5b03", null ],
    [ "Primary_Name", "structcompanion__classes.html#a8eea48a8563cb2ec30e24540130e2787", null ],
    [ "secondary_class", "structcompanion__classes.html#a2ef1f238da23ab9141fed6a416999ecc", null ],
    [ "Secondary_Name", "structcompanion__classes.html#a08c38ab3305c018024877696439e9899", null ]
];