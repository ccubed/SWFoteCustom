var structreset__data =
[
    [ "arg1", "structreset__data.html#a892bc4a7e8a51648dea5995993d00e1a", null ],
    [ "arg2", "structreset__data.html#a3280e70e2579727db9c8a1c1b563aa99", null ],
    [ "arg3", "structreset__data.html#a6aa3b05cb89dce6a258b243091f51ed9", null ],
    [ "command", "structreset__data.html#abd263424556f1e8df1416fd084e0e0e1", null ],
    [ "extra", "structreset__data.html#a1b4dd23ff7ddb9f2926230fe19d84df9", null ],
    [ "first_reset", "structreset__data.html#a1efd080cd4cd8f5e9bc5c35556f41e1d", null ],
    [ "last_reset", "structreset__data.html#a1065b25ad973b36d2d16ef5f5f9e2727", null ],
    [ "next", "structreset__data.html#a970a80e250723327432365f14d118603", null ],
    [ "next_reset", "structreset__data.html#ad7a43134b907ac6c65908896933b5453", null ],
    [ "prev", "structreset__data.html#a4afa92f123e3bf6f2f6550ba1587ebcf", null ],
    [ "prev_reset", "structreset__data.html#a5e14f77cce9b43ba76fefe26972fb10e", null ]
];