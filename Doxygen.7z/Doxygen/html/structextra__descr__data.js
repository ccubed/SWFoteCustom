var structextra__descr__data =
[
    [ "description", "structextra__descr__data.html#a13f183c6a3726eb38afd80e8e2d0cf84", null ],
    [ "keyword", "structextra__descr__data.html#a0173f2f9f733957566645b4a5b5b4d1e", null ],
    [ "next", "structextra__descr__data.html#ad6ef861a3aa1333177fc1793e7f01aa0", null ],
    [ "prev", "structextra__descr__data.html#a69aad56e70b801e06ce9257516458597", null ]
];