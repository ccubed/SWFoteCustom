var structimc__command__table =
[
    [ "connected", "structimc__command__table.html#adc842714e029b01aab816270f8c8d01d", null ],
    [ "first_alias", "structimc__command__table.html#a7b38095f30cd44f7b55265cdbe42c3b3", null ],
    [ "function", "structimc__command__table.html#a76e34c80f0db5f214a56e622d294502c", null ],
    [ "last_alias", "structimc__command__table.html#af884a005fc3f6f4d9b06fb9fdd1b1feb", null ],
    [ "level", "structimc__command__table.html#ae690bec93e8d412b91eb6274d738fc28", null ],
    [ "name", "structimc__command__table.html#aa1d2d98b416da917b15897a4ec79f64f", null ],
    [ "next", "structimc__command__table.html#a83ad85eeed13907a682cb36102ec81fd", null ],
    [ "prev", "structimc__command__table.html#a47c1f6b19427d88de4294c56658dfc01", null ]
];