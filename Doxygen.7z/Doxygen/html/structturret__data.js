var structturret__data =
[
    [ "laserstate", "structturret__data.html#aa1123c5b119f1796e987a9fbffe3afc0", null ],
    [ "next", "structturret__data.html#a816ccc91c91e1694c3b3eceb84fbb302", null ],
    [ "prev", "structturret__data.html#a3944884e8c737f65cd750122968bccd2", null ],
    [ "room", "structturret__data.html#a4c4c5b2863a9e051f106e2850aa7fb64", null ],
    [ "target", "structturret__data.html#a38631380d7d87e665316cb7493ad702d", null ]
];