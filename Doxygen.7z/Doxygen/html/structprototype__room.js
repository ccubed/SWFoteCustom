var structprototype__room =
[
    [ "desc", "structprototype__room.html#a1e6daaec1d15e459b596c4d65250b2de", null ],
    [ "exflags", "structprototype__room.html#a30cd42c9295a4c2ec0a70eb1a3ef2e19", null ],
    [ "exits", "structprototype__room.html#a13d581ab56b4dcd0b18bb0581f2acbd8", null ],
    [ "flags", "structprototype__room.html#af69ead87fae79bb9da2807dad68523ef", null ],
    [ "keys", "structprototype__room.html#a099e8a27bae1da0be433081907ca579d", null ],
    [ "name", "structprototype__room.html#a4224e2765ad839034d588dc466f970bb", null ],
    [ "next", "structprototype__room.html#a29ae4c5e46dcd632c3c1bb762a38176e", null ],
    [ "prev", "structprototype__room.html#ad08dcfe632133655a340bf4bc8bc6f4f", null ],
    [ "reset", "structprototype__room.html#aaea15adf67f8df4aa603df8529334d03", null ],
    [ "room_num", "structprototype__room.html#ae659c36f9886cb0354d749897480867e", null ],
    [ "room_type", "structprototype__room.html#a94347ab6f187eef10d0c27bc8d0b0657", null ],
    [ "rprog", "structprototype__room.html#afcd241ea21bea1110c34c749a9147e8d", null ],
    [ "tunnel", "structprototype__room.html#a69203419370de445a1accf5c828da37b", null ],
    [ "what_prototype", "structprototype__room.html#a2c29c6fc1feba57dee0b8a3501f1842c", null ]
];