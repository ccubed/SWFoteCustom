var structguard__data =
[
    [ "mob", "structguard__data.html#a6f61119b82c78a44260f817db01fd4ea", null ],
    [ "next", "structguard__data.html#ab6c62195672386491509da12c40793e7", null ],
    [ "next_on_planet", "structguard__data.html#a1077ee1b4f7cf729c8f07d266ee31d3e", null ],
    [ "planet", "structguard__data.html#a0728aafe5d43a7f3534cc59bc574eb19", null ],
    [ "prev", "structguard__data.html#a055139287226888f6ff52eb7b934f5fa", null ],
    [ "prev_on_planet", "structguard__data.html#a360cc8b0f34adb4d769d0681dac96d18", null ],
    [ "reset_loc", "structguard__data.html#a5556b0f33cb726b380a4649387ef8791", null ]
];