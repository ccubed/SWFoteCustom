var structimc__channel =
[
    [ "emoteformat", "structimc__channel.html#ab83cc18970882e860fa2ea4ecdc10102", null ],
    [ "excluded", "structimc__channel.html#a601f5880650986b8e10f799bf51ccd09", null ],
    [ "flags", "structimc__channel.html#a88b706a7ea4c55eb415a0df4c06eb181", null ],
    [ "history", "structimc__channel.html#aab579c0716efebba55c9fbebbb884f5f", null ],
    [ "invited", "structimc__channel.html#a759937d9a4d104b9e5efa8e4d0342e63", null ],
    [ "level", "structimc__channel.html#aa6751333ee7d9daf0bc65a25c2a17727", null ],
    [ "local_name", "structimc__channel.html#a39f7d8a381c38708f26c0c43e22da0bc", null ],
    [ "name", "structimc__channel.html#ad9fcc1f636f0e59e89d7dbc4c93ec9a2", null ],
    [ "next", "structimc__channel.html#aa3cbb424547f637c79253152f0db7b2d", null ],
    [ "open", "structimc__channel.html#a87907d4fc64f764cff288300d637a076", null ],
    [ "operators", "structimc__channel.html#a45d68af93c8b2164cf897e69e34a323b", null ],
    [ "owner", "structimc__channel.html#a6eadffe3a882fe600ab608c91d029b67", null ],
    [ "prev", "structimc__channel.html#a8c13e5d6532274a8cbee84f1e9698a10", null ],
    [ "refreshed", "structimc__channel.html#aaea648ff2c509fd6f0cba837fca73445", null ],
    [ "regformat", "structimc__channel.html#abdafcfa2b364eef08dd8096998757642", null ],
    [ "socformat", "structimc__channel.html#ab55aa9d3cb169fd40c5e95ae39ea042e", null ]
];