var structimc__packet__data =
[
    [ "field", "structimc__packet__data.html#a00319d66d5a36f82e2a0d15b1d4a1955", null ],
    [ "next", "structimc__packet__data.html#a392f394e56f56492925d1b6276155aa0", null ],
    [ "prev", "structimc__packet__data.html#a0fdb1b95f108d77e9ae5e5b5ced63e02", null ]
];