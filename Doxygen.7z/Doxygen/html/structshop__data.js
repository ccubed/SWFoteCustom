var structshop__data =
[
    [ "buy_type", "structshop__data.html#ac871d82d09952b2817eff591ab4ad3ef", null ],
    [ "close_hour", "structshop__data.html#a4310721b784a832975e1fa6e662eb11e", null ],
    [ "keeper", "structshop__data.html#adb24e84b3c10a0d604419c6d0f76e670", null ],
    [ "next", "structshop__data.html#ad57d63b7ab7f6b307da4b4233e60bc0a", null ],
    [ "open_hour", "structshop__data.html#a8e8fef29fd9419eba4e02aa3536610f7", null ],
    [ "player_shop", "structshop__data.html#a0da24927ba6e81237d0b8579bd727308", null ],
    [ "prev", "structshop__data.html#a795111fdaf2458cd4c7f24c6f00bb2ae", null ],
    [ "profit_buy", "structshop__data.html#a73eb3c5cedda8d0570b2df6d065d52e9", null ],
    [ "profit_sell", "structshop__data.html#a2bf862e87d0d1dce57b4ed7c8f90b855", null ]
];