var structwizent =
[
    [ "last", "structwizent.html#a23bffd077a7be8c4165114ef0d62d41d", null ],
    [ "level", "structwizent.html#a4a6407bc08a7b4a27d5cc24d867c0a4f", null ],
    [ "name", "structwizent.html#a20df9f15ee78a45875127b19817b70d5", null ],
    [ "next", "structwizent.html#adce624feb46b7dac3ff16329032e8535", null ]
];