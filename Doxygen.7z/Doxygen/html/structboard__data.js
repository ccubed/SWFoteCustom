var structboard__data =
[
    [ "board_obj", "structboard__data.html#ad8f564235df96b5a47cd1fe2a669a066", null ],
    [ "extra_readers", "structboard__data.html#a7e4764f95651d4431095b63103226e37", null ],
    [ "extra_removers", "structboard__data.html#a2abbf3d44bfb5fee3b14bd60c7848c8b", null ],
    [ "first_note", "structboard__data.html#af454e02dc4b2a757feaa31aa74929b06", null ],
    [ "last_note", "structboard__data.html#ad5ad00bf8324d60fd43880baa72fd771", null ],
    [ "max_posts", "structboard__data.html#aafe4591170b2afd53cbb511decc7529e", null ],
    [ "min_post_level", "structboard__data.html#acfa7cfd67cf191426634908acad2e5ae", null ],
    [ "min_read_level", "structboard__data.html#af181bc1b2e3c5c7a44494ea7fb824eb3", null ],
    [ "min_remove_level", "structboard__data.html#a795b3bafaef6ff912ae7f02d5b857f31", null ],
    [ "next", "structboard__data.html#a634ec853521e8005a4a26ed28c03d63c", null ],
    [ "note_file", "structboard__data.html#a5e5a144bfee85b522ce86e8fbad36534", null ],
    [ "num_posts", "structboard__data.html#ad23cb12948918d82bc427c2d646a7a97", null ],
    [ "post_group", "structboard__data.html#a7df892cb6731bb2dbc127453c1f389a0", null ],
    [ "prev", "structboard__data.html#a12c3620d9c3dbbf898f29c12266c3a6e", null ],
    [ "read_group", "structboard__data.html#a996697fc5779a3a0f53c4057c980a23d", null ],
    [ "type", "structboard__data.html#a1ab36cf60d3dc5ce5aa58c755a9ca86a", null ]
];