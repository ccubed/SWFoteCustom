var structextracted__char__data =
[
    [ "ch", "structextracted__char__data.html#aaed988556e1905a21f49245dddc67d28", null ],
    [ "extract", "structextracted__char__data.html#ae02601a5233b1ebb256b0a50f4866642", null ],
    [ "next", "structextracted__char__data.html#aed7f3c06996962f9dedbdc8be861fddf", null ],
    [ "retcode", "structextracted__char__data.html#ab64c4ae8a87818214221b9128d31bfe8", null ],
    [ "room", "structextracted__char__data.html#ae7a250c147f40a92f955575a5b54d419", null ]
];