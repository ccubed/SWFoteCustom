var structimc__packet =
[
    [ "first_data", "structimc__packet.html#a10c0366937f3bcb2d540aa6c9556ebba", null ],
    [ "from", "structimc__packet.html#a78082793bbabdbb49580c68f68dd91f6", null ],
    [ "last_data", "structimc__packet.html#a4358e95492e61021ed3de3737c76be1c", null ],
    [ "route", "structimc__packet.html#a51357ce62000db0e733f74f8033a6318", null ],
    [ "to", "structimc__packet.html#a5fa3fe1ad7680e9ffd24d2bab84f3d68", null ],
    [ "type", "structimc__packet.html#a76433e2a23601acd7ad5e10ad75938ed", null ]
];