var structrepairshop__data =
[
    [ "close_hour", "structrepairshop__data.html#a458161f4b57cb04763f0184de9a683cb", null ],
    [ "fix_type", "structrepairshop__data.html#ad3632430f0e98c88090131b2b4398059", null ],
    [ "keeper", "structrepairshop__data.html#a4e124a41c81c44b311664001fe5c2b2a", null ],
    [ "next", "structrepairshop__data.html#a2d924e56c5d0b2ddad15ec05f32ec4aa", null ],
    [ "open_hour", "structrepairshop__data.html#a115409a78e82c4b28c19a96ad845b129", null ],
    [ "prev", "structrepairshop__data.html#a9dc093f2e7abd94982e3083b309145c8", null ],
    [ "profit_fix", "structrepairshop__data.html#ae28d69d9ae9423ed1c37dc4974fb4c9f", null ],
    [ "shop_type", "structrepairshop__data.html#a5009696456226b80a6adaefb1f14dc8a", null ]
];