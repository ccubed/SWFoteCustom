var structimc__remoteinfo =
[
    [ "expired", "structimc__remoteinfo.html#aef3e2f23bda30ac18217a9e2133daa37", null ],
    [ "host", "structimc__remoteinfo.html#ab2e0bc370051a77d5ccea7c5daeb5778", null ],
    [ "name", "structimc__remoteinfo.html#a4f25ca23b6f7ae90c550d9558359778f", null ],
    [ "network", "structimc__remoteinfo.html#ae70de3aa24a1a9b1c60aae708fbc0e6d", null ],
    [ "next", "structimc__remoteinfo.html#a7d2d74dc18c5d7f8be9f566260fabed4", null ],
    [ "path", "structimc__remoteinfo.html#a68f229f02c53376264219f0394a26e1a", null ],
    [ "port", "structimc__remoteinfo.html#aedda234754b983365528ff97e4720c2d", null ],
    [ "prev", "structimc__remoteinfo.html#ab9cce8fe44391b0df46d6dce422a2e57", null ],
    [ "url", "structimc__remoteinfo.html#aea3040683a76d2288ca53d05381c8002", null ],
    [ "version", "structimc__remoteinfo.html#a6ebcf1b5e5da53f7d8c5e2ae3a3a90e5", null ]
];