var structimc__help__table =
[
    [ "level", "structimc__help__table.html#a40de9cf2539bb448f41c8dba5d9ffee3", null ],
    [ "name", "structimc__help__table.html#acfa8f4cb7ec15595a1b4b9e22c83e513", null ],
    [ "next", "structimc__help__table.html#a137d67484a457d5a66b60a56f4b96d5a", null ],
    [ "prev", "structimc__help__table.html#aef1f63c1dc96bd32b8286a39f2ae8936", null ],
    [ "text", "structimc__help__table.html#ac6b4d713636b8a2f564023f28c69b02c", null ]
];