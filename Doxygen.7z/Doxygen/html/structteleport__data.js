var structteleport__data =
[
    [ "next", "structteleport__data.html#aebaa07bf50758464e06bf70eaf872e25", null ],
    [ "prev", "structteleport__data.html#acb8cb03712a6e11cd84613fe99533480", null ],
    [ "room", "structteleport__data.html#a38ba3e9094b74010303b58bb0ff0a350", null ],
    [ "timer", "structteleport__data.html#a5fa225fdfafa51f1143e1ef1d78c6fb0", null ]
];