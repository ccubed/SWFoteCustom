var makeobjs_8c =
[
    [ "create_money", "makeobjs_8c.html#a7503e8f8a426c34365cb796a248aafbd", null ],
    [ "make_blood", "makeobjs_8c.html#aba4aec46682a0a10bface13dd25cb390", null ],
    [ "make_bloodstain", "makeobjs_8c.html#aff24f2a3ddc933d9ede3a6f01f43cd9c", null ],
    [ "make_corpse", "makeobjs_8c.html#a5263507b384f960cc4b20331b62c5c0c", null ],
    [ "make_fire", "makeobjs_8c.html#a73ddbf63567b3fe48512129f4664ad5a", null ],
    [ "make_scraps", "makeobjs_8c.html#aa3416bb4924cf9d72ec623509ffa4a68", null ],
    [ "make_trap", "makeobjs_8c.html#a15ab9967cceb0331f06033150be46e95", null ]
];