var structhelp__data =
[
    [ "keyword", "structhelp__data.html#add6106e94cd862ac363b11d1d9ecf9dd", null ],
    [ "level", "structhelp__data.html#a1849e0d20943772ef0116bc1aff8d0c6", null ],
    [ "next", "structhelp__data.html#a5e9c4f39cfc8bc5ad3d28f9141c9fc1d", null ],
    [ "prev", "structhelp__data.html#a86db6ab812f79afdd9a71f9fe1572c80", null ],
    [ "text", "structhelp__data.html#aae40a007cea7594faa2dcc0947c3d60e", null ]
];