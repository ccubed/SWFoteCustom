var structmob__prog__data =
[
    [ "arglist", "structmob__prog__data.html#ae365d37396988e5ecb5e13b312ef46ec", null ],
    [ "comlist", "structmob__prog__data.html#a05c0a34e08bcdbad3962393bce3f6151", null ],
    [ "fileprog", "structmob__prog__data.html#a7a92d32e0ca8f3f06ba3d544cbc3cf58", null ],
    [ "next", "structmob__prog__data.html#ad847311d57f7c24945edc421472b37b9", null ],
    [ "resetdelay", "structmob__prog__data.html#ac5bab08e6b798e26f0e599500c7fb881", null ],
    [ "triggered", "structmob__prog__data.html#a17c424cb94245cd2c37d1cf731b80606", null ],
    [ "type", "structmob__prog__data.html#a00755954a419bae0695bef839d9c4cc5", null ]
];