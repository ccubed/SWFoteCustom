var structaffect__data =
[
    [ "bitvector", "structaffect__data.html#af95f32ee498c34105a1cc15674347cb3", null ],
    [ "duration", "structaffect__data.html#a2d02b0904c7173ff2d8f64489210fc1f", null ],
    [ "location", "structaffect__data.html#a61451fc3abc6f4736da75fa455568076", null ],
    [ "modifier", "structaffect__data.html#a047e8ef498d8167ca96e80bce6e914a1", null ],
    [ "next", "structaffect__data.html#a5cf05e02a0e5293e06d10e5f39b18dd8", null ],
    [ "prev", "structaffect__data.html#a7d9a1028cde89ed06adcbe3e42b6b686", null ],
    [ "type", "structaffect__data.html#ab17440a6e15d0ea3ddf182e698dcbf74", null ]
];