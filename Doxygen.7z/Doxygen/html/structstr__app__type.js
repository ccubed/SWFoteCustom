var structstr__app__type =
[
    [ "carry", "structstr__app__type.html#a1d5099dc382f24be1516f5efd6afb84d", null ],
    [ "todam", "structstr__app__type.html#a75aadbbb83bc7597a7d796300b45a5b0", null ],
    [ "tohit", "structstr__app__type.html#a641ea37815ebbdb2464e8adf684b3d1c", null ],
    [ "wield", "structstr__app__type.html#a4b76d87a8b02e712b2d47f8cdcf77338", null ]
];