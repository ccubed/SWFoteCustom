var structbfs__queue__struct =
[
    [ "dir", "structbfs__queue__struct.html#a1b4779043921027a162a4679d60a470c", null ],
    [ "next", "structbfs__queue__struct.html#a59db314a224e075250cb76a491d4ee8c", null ],
    [ "room", "structbfs__queue__struct.html#af79e73eb529b2ada97e3441ed0b0fa33", null ]
];