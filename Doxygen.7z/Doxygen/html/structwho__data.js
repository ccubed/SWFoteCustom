var structwho__data =
[
    [ "next", "structwho__data.html#a0bbd3d4add585f0278875a1b3e15ee78", null ],
    [ "prev", "structwho__data.html#a3c3f9fabf8e23abab50224b62ce7954c", null ],
    [ "text", "structwho__data.html#a17871cdcedc2b7c964ef552be5c893c6", null ],
    [ "type", "structwho__data.html#a041d053b0b0331a7ac394582bb508587", null ]
];