var structhall__of__fame__element =
[
    [ "award", "structhall__of__fame__element.html#a043c30780803b3d147c19a927d175987", null ],
    [ "date", "structhall__of__fame__element.html#a0317f0ce1b933bd56321dd49862dc21f", null ],
    [ "name", "structhall__of__fame__element.html#afb2abe66c6cdb9e29f4f7c8b0d2971c5", null ],
    [ "next", "structhall__of__fame__element.html#a3100b7c771820bf022fd8f2cbad57b40", null ]
];