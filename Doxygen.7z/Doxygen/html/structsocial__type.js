var structsocial__type =
[
    [ "char_auto", "structsocial__type.html#a8b0366c077338417e3b610b3699d67a0", null ],
    [ "char_found", "structsocial__type.html#aa719ad5c6b135e84edb367ddcb9103b6", null ],
    [ "char_no_arg", "structsocial__type.html#a695d9687595216daeb2f5aa5ec8db593", null ],
    [ "name", "structsocial__type.html#a0babd8c283dd975ba94540b9fa1f9573", null ],
    [ "next", "structsocial__type.html#ad7ab8a87447abcca203ab27584d78b31", null ],
    [ "others_auto", "structsocial__type.html#abebeb9aad9c560108a1a95b5a25735fe", null ],
    [ "others_found", "structsocial__type.html#a31f6e30146faed92bf51e53c074e7414", null ],
    [ "others_no_arg", "structsocial__type.html#acc7c23077c4bd75af3c038c3ccf603f2", null ],
    [ "vict_found", "structsocial__type.html#a15ed1bc2b92d330f768adf3c8cf7c7d1", null ]
];