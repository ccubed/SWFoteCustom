var structmissile__data =
[
    [ "age", "structmissile__data.html#a6dc431b30c4c10ff5300c98f7c715f96", null ],
    [ "fired_by", "structmissile__data.html#ab8a042e53f4ac56c72b8e5d990234813", null ],
    [ "fired_from", "structmissile__data.html#a0fbf77d81b0c62f880394fd2256a4960", null ],
    [ "missiletype", "structmissile__data.html#a4306820038fa012c88f881e67544cdb9", null ],
    [ "mx", "structmissile__data.html#a9d5c8721b2680b32ef68941bbec52b71", null ],
    [ "my", "structmissile__data.html#aac4155a90b12355a72cfad579560314b", null ],
    [ "mz", "structmissile__data.html#aa9e24553b11c9e2fe5cb35458c4be624", null ],
    [ "next", "structmissile__data.html#a5e97c5aebe55676a0e35a55c6a46d704", null ],
    [ "next_in_starsystem", "structmissile__data.html#a14c1fcf3f00310872ac92de0c8895d89", null ],
    [ "prev", "structmissile__data.html#a0c9cf63605e629af1a74e5a133a377df", null ],
    [ "prev_in_starsystem", "structmissile__data.html#a25a20c9362270f11c420105a5f21770e", null ],
    [ "speed", "structmissile__data.html#a8a4a01d65bf8825cbca00457cc0ec703", null ],
    [ "starsystem", "structmissile__data.html#acb6d6189a6f7914720fd8722117584f5", null ],
    [ "target", "structmissile__data.html#a950553e1727df5eba9f46856828d8c65", null ]
];