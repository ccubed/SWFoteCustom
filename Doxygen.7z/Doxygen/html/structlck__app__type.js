var structlck__app__type =
[
    [ "luck", "structlck__app__type.html#ae0a4328732895a654d3701d7fb473813", null ]
];