var functions_8c =
[
    [ "chrmax", "functions_8c.html#a098eb513ed7339101c7b493f9b45e1e4", null ],
    [ "format_str", "functions_8c.html#a98a7da5f1747ee926e66c419bf859046", null ],
    [ "htmlcolor", "functions_8c.html#a37968cca6aa67c3ea2661ec1594a8ecc", null ],
    [ "remand", "functions_8c.html#a2dee8268893931dcf328a63357a975ec", null ],
    [ "rembg", "functions_8c.html#a59a25f968569d7f6f647c801802dfc38", null ],
    [ "strlen_color", "functions_8c.html#af1f9403b67a744351ed09fcfe8d44df5", null ],
    [ "strlinwrp", "functions_8c.html#a262ef9ddd60e30e8e33ea8559c8a92eb", null ],
    [ "strrep", "functions_8c.html#a25756d3d0193da601dadc0b4239c7d7c", null ]
];