var structability__bonus =
[
    [ "Assassin", "structability__bonus.html#aa2245364af6c192271c496dc8f937483", null ],
    [ "Bounty_Hunting", "structability__bonus.html#a74263f44c1676cd583c47615a6e2f826", null ],
    [ "Combat", "structability__bonus.html#a8edf77b1579efefa1a1d65142cdbc878", null ],
    [ "Engineering", "structability__bonus.html#a19789e2a318b5df07f5fbb55a5579b76", null ],
    [ "Force", "structability__bonus.html#a02f372a7d69e06dcc5bdae95d9ea24e2", null ],
    [ "Piloting", "structability__bonus.html#af5e2ff78c40c9177732f594aa8dad98e", null ],
    [ "Politician", "structability__bonus.html#af22d1494d38def6ca1e6448b44072dbc", null ],
    [ "Race_Name", "structability__bonus.html#a0784c2e275649f9c0faa08beb1a9a342", null ],
    [ "Slicer", "structability__bonus.html#ab69a79eb2910e6644f120b646b8b22f5", null ],
    [ "Smuggling", "structability__bonus.html#a46193286c1fc8dc4427a6f69c4902cc5", null ],
    [ "Technician", "structability__bonus.html#a6135bda32dcdb8774c3fef41fd363546", null ]
];