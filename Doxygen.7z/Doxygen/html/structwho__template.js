var structwho__template =
[
    [ "head", "structwho__template.html#a37f6a24c5b2a9771af6c617113978ea5", null ],
    [ "immheader", "structwho__template.html#a81d7b7cb5776506164f668196dfd640b", null ],
    [ "immline", "structwho__template.html#a8db95cbb345b1b107ffa0b60f7e77d95", null ],
    [ "master", "structwho__template.html#a1cea34a45915b439b579c4c582eb77f3", null ],
    [ "plrheader", "structwho__template.html#ac5fc66cdacac7decee4e658e76f990f1", null ],
    [ "plrline", "structwho__template.html#adb234c580ec993942f3a107b124939eb", null ],
    [ "tail", "structwho__template.html#a9628686a550ed454433aeae4438bb2e5", null ]
];