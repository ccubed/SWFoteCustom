var structrace__type =
[
    [ "affected", "structrace__type.html#a88a91c7d3142f2d6332e1c297d5698c5", null ],
    [ "cha_plus", "structrace__type.html#a9623ec791a46875a5ef968ad7b3e4674", null ],
    [ "class_restriction", "structrace__type.html#a3f53ee9c9533ef5c5263ff63e938a69b", null ],
    [ "con_plus", "structrace__type.html#af780f26963e3a0be420c6d4081f971a5", null ],
    [ "dex_plus", "structrace__type.html#a7eece055eb91c19f2203595ab909c0e6", null ],
    [ "frc_plus", "structrace__type.html#a1ceaa7316efcfafc65e41213f733bb5b", null ],
    [ "hit", "structrace__type.html#ab16e3b257462365a64939bf7f36604b0", null ],
    [ "int_plus", "structrace__type.html#a5b3db98bc83beda27f862164771100e6", null ],
    [ "language", "structrace__type.html#aac098daa96ac5103f23d955d1c5f024f", null ],
    [ "lck_plus", "structrace__type.html#a431d6cb9e97d3ba0edde605b0b0dd157", null ],
    [ "mana", "structrace__type.html#aa1fd2984a8d95835a916e84472b7e5f6", null ],
    [ "race_name", "structrace__type.html#a003920d2c722216b527d21cf4ae3446e", null ],
    [ "resist", "structrace__type.html#ad1b37b7e2971d9a1fd3155d560d9b127", null ],
    [ "str_plus", "structrace__type.html#a52581d577de0a14709c274eafaab1d1d", null ],
    [ "suscept", "structrace__type.html#af33c36b768f64c4535cb1b2381c423eb", null ],
    [ "wis_plus", "structrace__type.html#a9443ac15586a9a370bcaba4176306692", null ]
];