var slicers_8c =
[
    [ "add_to_s", "slicers_8c.html#acf6879fde87970ca16784cc3d6725d41", null ],
    [ "acctname", "slicers_8c.html#a377cde8c7087cd7c7a12bd2464988be6", null ],
    [ "autofly", "slicers_8c.html#a7e36993c8255a86f79abd336ad6d5e04", null ],
    [ "do_assignpilot", "slicers_8c.html#a9619e5aafe04665acceb72b1922cbbcc", null ],
    [ "do_checkprints", "slicers_8c.html#a94550591f069a7e5178478c7e9a0161f", null ],
    [ "do_codecrack", "slicers_8c.html#a1b22e2eec145041d68e3b38cb18aecd1", null ],
    [ "do_disableship", "slicers_8c.html#adf3050fa1c1b73d29f1970cbd28d5b07", null ],
    [ "do_inquire", "slicers_8c.html#a1b0aaba98e07afb3671e77a708d4b707", null ],
    [ "do_makecommsystem", "slicers_8c.html#a33166a2c741bd728763776b7dc3af180", null ],
    [ "do_makedatapad", "slicers_8c.html#a2a4903b9abc4044d483441397c56410a", null ],
    [ "do_slicebank", "slicers_8c.html#a92c4a4bbce07d0dfef32093de436d3a3", null ],
    [ "do_tellsnoop", "slicers_8c.html#a413738fc8f4e96b674ab4e8e95e684cf", null ],
    [ "blaha", "slicers_8c.html#a8f033368944e9297e343710b49e271d3", null ],
    [ "disable", "slicers_8c.html#a407589079fa9b1b9d17b700f469168e3", null ],
    [ "title", "slicers_8c.html#ac7243b9ca745beb946d1633c0970c3a5", null ]
];