var reset_8c =
[
    [ "add_obj_reset", "reset_8c.html#ac07432ffe55e58ab4157b17e356197dc", null ],
    [ "add_reset", "reset_8c.html#adaffa5782aa359a2e299498562b9f13b", null ],
    [ "count_obj_list", "reset_8c.html#a03c6f5e44d21372364bd76cc961c33c8", null ],
    [ "delete_reset", "reset_8c.html#a9ab2c56c3090410ea4f569e3642f7e9d", null ],
    [ "do_instaroom", "reset_8c.html#ae3f3a97d56f66ec5e287dd30a39241cb", null ],
    [ "do_instazone", "reset_8c.html#a27123f52364b33fad449204681bead79", null ],
    [ "do_reset", "reset_8c.html#a98d76dcead0dc18c992bafa47765c286", null ],
    [ "find_oreset", "reset_8c.html#a4289ea883ecf3cf92d247fc753cd63cb", null ],
    [ "generate_itemlevel", "reset_8c.html#a46c72e0b78bf3d48082051295c48b7e0", null ],
    [ "get_obj_type", "reset_8c.html#a56f84ff2fc1abf1d54ae70f6428cae0f", null ],
    [ "get_trapflag", "reset_8c.html#a7df92a40f29c1bb1457e925fef0bd47a", null ],
    [ "instaroom", "reset_8c.html#a0cf83440a98abb53b63fb6a12e9a658a", null ],
    [ "make_reset", "reset_8c.html#af2bde719e53169897f77ffc7e95e7243", null ],
    [ "renumber_put_resets", "reset_8c.html#a1676dc97c69b8c631ee606cfa6d8b428", null ],
    [ "reset_area", "reset_8c.html#a41c139b0d3ef55cae6dff8372d0456fa", null ],
    [ "reset_room", "reset_8c.html#a2f57a5fa5a2f1dc21671357cc1d83b35", null ],
    [ "sprint_reset", "reset_8c.html#ae802d05c267a07ff069d0e21b33a33f1", null ],
    [ "wipe_area_resets", "reset_8c.html#a92e4182a37b6df39cdb1c9bbf10c63b0", null ],
    [ "wipe_resets", "reset_8c.html#ab50637e78bd4358f3a5d91a35628be10", null ],
    [ "top_reset", "reset_8c.html#a0dc79f5c3c4110fbaf96ea980bdc54d3", null ],
    [ "wear_locs", "reset_8c.html#a835ad53ef2e785f450c61da5c0543cc6", null ]
];