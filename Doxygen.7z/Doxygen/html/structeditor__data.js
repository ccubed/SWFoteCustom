var structeditor__data =
[
    [ "desc", "structeditor__data.html#adb77f2e270bb1ca62dbce410c30f9121", null ],
    [ "first_line", "structeditor__data.html#ab720ca33a8c41326f300e7ce8f4a53d4", null ],
    [ "line_count", "structeditor__data.html#a9ccd3ab4d4f9bde5e81664aa1933a596", null ],
    [ "max_size", "structeditor__data.html#af2dd828c91dfaaf0783e2e2c7dee9932", null ],
    [ "on_line", "structeditor__data.html#a5b32f7ad251712590138e2f2b7e15e72", null ],
    [ "text_size", "structeditor__data.html#a3fe4926e73f08632cef8b71b06798404", null ]
];