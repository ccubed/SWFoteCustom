var structcmd__type =
[
    [ "do_fun", "structcmd__type.html#aabdf5a971799e59aa7350877aa0df7fd", null ],
    [ "level", "structcmd__type.html#af2d8d708f80e3ab28ec897b796829e32", null ],
    [ "log", "structcmd__type.html#ae13e12f2f86230c283dcbf74a29185cb", null ],
    [ "name", "structcmd__type.html#aa351f84456e7d4f8ad1a16a79e95c04a", null ],
    [ "next", "structcmd__type.html#ae95ffe90d4b985be7dd5340ce75328b8", null ],
    [ "position", "structcmd__type.html#a7f310e8323ede50d39652f23ed09031f", null ],
    [ "userec", "structcmd__type.html#a41439c22d8c2a1a9a94deb556dd7e387", null ]
];