var structimcucache__data =
[
    [ "gender", "structimcucache__data.html#a79fd373a76111daedd2185c7ca6b7749", null ],
    [ "name", "structimcucache__data.html#acd830fbd99ed217ad07c1b0d5c589ef0", null ],
    [ "next", "structimcucache__data.html#ab58bfed1e7056f862da0dc4646bf8b54", null ],
    [ "prev", "structimcucache__data.html#ad71b8d5db9db9148487e590a2a4bd893", null ],
    [ "time", "structimcucache__data.html#a4bd3c22947e739da7356280c0da0c5d9", null ]
];