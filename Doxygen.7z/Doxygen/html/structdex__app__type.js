var structdex__app__type =
[
    [ "defensive", "structdex__app__type.html#a4daadde1f8c385182518eba0e9281a96", null ]
];