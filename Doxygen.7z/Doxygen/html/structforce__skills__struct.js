var structforce__skills__struct =
[
    [ "alter", "structforce__skills__struct.html#a2bde751feb8a2c3a9215b120179b1d11", null ],
    [ "ch_effect", "structforce__skills__struct.html#a2e8c295176a36edea82fe41ce938b29c", null ],
    [ "code", "structforce__skills__struct.html#a04079ecdaa5b65b691534139f1dc6735", null ],
    [ "control", "structforce__skills__struct.html#a9f71208ac361f61af9ff4cb01c56b2a0", null ],
    [ "cost", "structforce__skills__struct.html#a532fa20207219208501aa893d90be2c5", null ],
    [ "disabled", "structforce__skills__struct.html#a9fbc35844dc3f1161a02fbeba4c20e69", null ],
    [ "do_fun", "structforce__skills__struct.html#afebe4f81bdb5e416f94f91e4aa00ed75", null ],
    [ "index", "structforce__skills__struct.html#ae8554dd74ffb60bb661bed49ee82da68", null ],
    [ "mastertrain", "structforce__skills__struct.html#a68c536679b30955fc3529fd35748cf29", null ],
    [ "name", "structforce__skills__struct.html#afad7a10bea700917b6647ef46af4bcc0", null ],
    [ "next", "structforce__skills__struct.html#ade440e33d0bd46d1a963805d1d73cd83", null ],
    [ "notskill", "structforce__skills__struct.html#ad1b5377923ab4e15631b40f289c848f6", null ],
    [ "prev", "structforce__skills__struct.html#a1c230f837c5e6f3ea0b60b1cf517e2f7", null ],
    [ "room_effect", "structforce__skills__struct.html#a62174df4925d8cd65d3b4681395fcf25", null ],
    [ "sense", "structforce__skills__struct.html#abf5b5e45f2541a10870ae1de4b8e6f73", null ],
    [ "status", "structforce__skills__struct.html#aab994286cde569657deca877a452e7e3", null ],
    [ "type", "structforce__skills__struct.html#a18349c43ae5af0f4d6848d53dcfd5705", null ],
    [ "victim_effect", "structforce__skills__struct.html#aab37258cdb4af01aa7b8f0b89655f64b", null ],
    [ "wait_state", "structforce__skills__struct.html#abbccd8e07fad613fe6f4c07838b7f98e", null ]
];