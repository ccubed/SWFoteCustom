var structmodule__data =
[
    [ "affect", "structmodule__data.html#a79d81c09a1c23c72dd95d88ad2f94138", null ],
    [ "ammount", "structmodule__data.html#a97a50dc3eda02794904ea1daf4768e4f", null ],
    [ "next", "structmodule__data.html#a4975b87f120a5704443ee1af64eafe91", null ],
    [ "prev", "structmodule__data.html#aadf99008a4a030351c95b0b61b35c4a7", null ]
];