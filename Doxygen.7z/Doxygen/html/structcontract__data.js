var structcontract__data =
[
    [ "amount", "structcontract__data.html#aa85c58bb2805fb5838c9a9f0e2667da9", null ],
    [ "next_in_contract", "structcontract__data.html#a47a0c72cc86b9c989ae9c0ff2a14c3bc", null ],
    [ "prev_in_contract", "structcontract__data.html#a6e849ac94b2daf989dc9ccadc38dcd40", null ],
    [ "target", "structcontract__data.html#a185074d1b8d6ed7d8c4cc54ccf5cf351", null ]
];