var structimc__ignore =
[
    [ "name", "structimc__ignore.html#aa92944ff8bed554304face78bc540550", null ],
    [ "next", "structimc__ignore.html#a569a7fc9d24075dd648b4a8a94483cc7", null ],
    [ "prev", "structimc__ignore.html#adf1f1ed2ead199bdb99ba07be1bff12c", null ]
];