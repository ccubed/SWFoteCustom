var structauction__data =
[
    [ "bet", "structauction__data.html#a7c0016b4b7ab8c6066adf85d65e79230", null ],
    [ "buyer", "structauction__data.html#a7527231cf25714736933de63332cac9c", null ],
    [ "going", "structauction__data.html#ad53c2e807ae455e7fafed499ff952324", null ],
    [ "item", "structauction__data.html#a3da626e96df018ff1be5b0e48be70408", null ],
    [ "pulse", "structauction__data.html#a1b458c276372dcebab41f3557df17865", null ],
    [ "seller", "structauction__data.html#aed1a2dd2e4512a6826f29442e60e4b33", null ],
    [ "starting", "structauction__data.html#a928a532c6518f4e032b86583a2971de5", null ]
];