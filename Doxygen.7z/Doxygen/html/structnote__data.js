var structnote__data =
[
    [ "abstentions", "structnote__data.html#a8d953b9e6afdd8b031c1cf42bbee5df3", null ],
    [ "date", "structnote__data.html#a1345d6fa8cc37c1d5764a61676a24bfb", null ],
    [ "next", "structnote__data.html#ae68b2117711b14d44080fd0591d48889", null ],
    [ "novotes", "structnote__data.html#a52bbeefc9bce24efa8efb29c29e97ec5", null ],
    [ "prev", "structnote__data.html#a1b8c569963ce33fac7075b3d8bcccbbd", null ],
    [ "sender", "structnote__data.html#a38f98987c75de40f55dc58438709f9ea", null ],
    [ "subject", "structnote__data.html#ac20889af7480143436f1417b87476607", null ],
    [ "text", "structnote__data.html#a2b553be2cf976d4884a47b302ebbbdb1", null ],
    [ "to_list", "structnote__data.html#ae6f0a1ca3303db9b794a1e94174760e3", null ],
    [ "voting", "structnote__data.html#aeef205c0ca8d6c4be981ac2cc1edec68", null ],
    [ "yesvotes", "structnote__data.html#af04d42028bd94a7d75efa99b7ed67502", null ]
];