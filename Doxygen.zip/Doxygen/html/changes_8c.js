var changes_8c =
[
    [ "NULLSTR", "changes_8c.html#ad214bb1a742e27501b2a970ce8cb6c5f", null ],
    [ "AddSpaces", "changes_8c.html#a6dbcaf1478399bb0cdf230e9bf943417", null ],
    [ "args", "changes_8c.html#a95b58fa7905036e46c42f4cc77106f2e", null ],
    [ "change_justify", "changes_8c.html#a55d44b46b5e0a3a6dbb40dcabda2f94a", null ],
    [ "current_date", "changes_8c.html#a906b8bd7cb9be3b8499525a417d8f87e", null ],
    [ "delete_change", "changes_8c.html#aac4360b5d96326af2df29bac1cd05e6d", null ],
    [ "do_addchange", "changes_8c.html#affb807f147d412ff77002ec97a398536", null ],
    [ "do_changes", "changes_8c.html#a67a31c5974d2aaa4734b2d8233501403", null ],
    [ "do_chedit", "changes_8c.html#aa7613278636ea99034681b678eeb1fe3", null ],
    [ "load_changes", "changes_8c.html#a1077fe3156a4af0450acb547cae86fb5", null ],
    [ "my_strftime", "changes_8c.html#ae91ade85ee8b8dd6db0bb4902744b564", null ],
    [ "num_changes", "changes_8c.html#a1b6db36760d05d35133d8d0f0dbe4886", null ],
    [ "save_changes", "changes_8c.html#a2b953aaa6c9d963f616751653fd0bf25", null ],
    [ "changes_table", "changes_8c.html#a180a1d8d1cb06b3fcab242d997426d86", null ],
    [ "maxChanges", "changes_8c.html#a7b8e6442baaef9c4a2d5a6c02e620f2f", null ]
];