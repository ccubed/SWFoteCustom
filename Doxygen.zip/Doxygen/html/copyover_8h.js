var copyover_8h =
[
    [ "CH", "copyover_8h.html#ace948017639c7620545e638ee9ce97a2", null ],
    [ "COPYOVER_DIR", "copyover_8h.html#a40bee1a8c045b93ecf570755f87133c3", null ],
    [ "COPYOVER_FILE", "copyover_8h.html#ab65015171bcc23577ec0d3cb73137431", null ],
    [ "EXE_FILE", "copyover_8h.html#a09067692d33ed1a7507d274d1bf64ccd", null ],
    [ "FCLOSE", "copyover_8h.html#aa134784410ec7cd9005882b963fe0d94", null ],
    [ "MOB_FILE", "copyover_8h.html#a1277d86ff9523110f5ff5f48856cf43f", null ],
    [ "SHIP_FILE", "copyover_8h.html#a5e640333c4ce65c94e61b2a420378830", null ],
    [ "hotboot_recover", "copyover_8h.html#afb133474918d8855dc5944a8a200ecb9", null ],
    [ "load_world", "copyover_8h.html#a6a50060d9b37407efa7ca2394673870f", null ]
];