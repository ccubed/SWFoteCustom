var comments_8c =
[
    [ "comment_remove", "comments_8c.html#a78f4cfd94035c326a90931d1e088413a", null ],
    [ "do_comment", "comments_8c.html#a073df1306c31130dbe6d1abdfb249a3f", null ],
    [ "fread_comment", "comments_8c.html#a8bde1b0b4333c58fb5abd3a27f29d22d", null ],
    [ "fwrite_comments", "comments_8c.html#a3963369e196a769562e9d980d4067129", null ],
    [ "note_attach", "comments_8c.html#ad2411652613fbe1f0999ffeb13f30366", null ]
];