var mccp_8c =
[
    [ "compressEnd", "mccp_8c.html#ae3beb3237cee602d342bc379ba3c8d41", null ],
    [ "compressStart", "mccp_8c.html#afcc394cbdbf91d7ca051a802a6f89ec5", null ],
    [ "do_compress", "mccp_8c.html#ab98b6313a607bffcf13a713f9a7b8b93", null ],
    [ "process_compressed", "mccp_8c.html#af054d6e018e59990d1dfc3f957c66bad", null ],
    [ "write_to_descriptor", "mccp_8c.html#af6513b3fee2870851515d8dd7d664722", null ],
    [ "start_compress2_str", "mccp_8c.html#ae0196b9994418b73d9fcc7cebf95ffe4", null ],
    [ "will_compress2_str", "mccp_8c.html#a506f01574d803256a18bad8a2453feee", null ]
];