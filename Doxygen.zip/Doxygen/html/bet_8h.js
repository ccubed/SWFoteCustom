var bet_8h =
[
    [ "advatoi", "bet_8h.html#a77e40489f3da87b28bd38b6cb5ef17b6", null ],
    [ "parsebet", "bet_8h.html#a9d0a42f5160eff79ff04192144729144", null ]
];