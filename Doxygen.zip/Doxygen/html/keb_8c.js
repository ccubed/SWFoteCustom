var keb_8c =
[
    [ "descriptor_switch", "keb_8c.html#a4f0d1737ce1550ae764c27803bb2880e", null ],
    [ "do_as_mortal", "keb_8c.html#a30f254b7b39f46c46cab4f0fdc766f2b", null ],
    [ "do_crash", "keb_8c.html#a6c853eec069637d3fb47b1613e682568", null ],
    [ "do_doas", "keb_8c.html#abd10377b144cc84876f50852e269980d", null ],
    [ "do_pfreload", "keb_8c.html#a4853b104b47ee3506387f9be130deabc", null ],
    [ "exists_player", "keb_8c.html#a5728fdf38f180bee62d0df430244b973", null ]
];