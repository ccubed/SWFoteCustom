var marriage_8c =
[
    [ "do_accept", "marriage_8c.html#ab47360a66c55001b933c307a1128e10e", null ],
    [ "do_decline", "marriage_8c.html#a3da9ac065bc28d0f4e2ed20e36c351e1", null ],
    [ "do_divorce", "marriage_8c.html#aaad0893e04d2f940fed9110e74889cef", null ],
    [ "do_marry", "marriage_8c.html#ad192f67502bb3e85318b4838df27cabf", null ],
    [ "do_propose", "marriage_8c.html#a2c8c078e8b2fd32ce19152ae3639ae3c", null ],
    [ "do_spousetalk", "marriage_8c.html#a949722d99d1f754b18508911ffc4bdda", null ]
];