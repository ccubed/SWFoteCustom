var searchData=
[
  ['ban_5fdata',['ban_data',['../structban__data.html',1,'']]],
  ['bfs_5fqueue_5fstruct',['bfs_queue_struct',['../structbfs__queue__struct.html',1,'']]],
  ['blackmarket_5fdata',['blackmarket_data',['../structblackmarket__data.html',1,'']]],
  ['board_5fdata',['board_data',['../structboard__data.html',1,'']]],
  ['bounty_5fdata',['bounty_data',['../structbounty__data.html',1,'']]],
  ['bug_5fdata',['bug_data',['../structbug__data.html',1,'']]]
];
