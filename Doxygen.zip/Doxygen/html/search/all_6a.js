var searchData=
[
  ['jail',['jail',['../structclan__data.html#a13aad95e7b32b999cfd4cb4fd0d0a8ac',1,'clan_data']]],
  ['jcount',['jcount',['../pfiles_8c.html#afcefa983ae9603ed6503ec5c434e2f80',1,'pfiles.c']]],
  ['jedi_5fbonus',['jedi_bonus',['../misc_8c.html#a4c4b177215f6913825a30c3b8150ef52',1,'misc.c']]],
  ['juking',['juking',['../structship__data.html#a200fd33a33c9082bf4ef19e2dd969839',1,'ship_data']]],
  ['jx',['jx',['../structship__data.html#a36baba4cb48748576940890d3ab3adac',1,'ship_data']]],
  ['jy',['jy',['../structship__data.html#a32218b20e47e98d3a5aca12c66de9cf7',1,'ship_data']]],
  ['jz',['jz',['../structship__data.html#a8b317e1ccba29593ca3be0545a9330e4',1,'ship_data']]]
];
