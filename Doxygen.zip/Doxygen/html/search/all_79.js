var searchData=
[
  ['y',['y',['../structplanet__data.html#a15a9544feb77f5f194193fb273a3a3f5',1,'planet_data::y()'],['../structmenu__data.html#ad633846c56290713509d9de69b9d83c6',1,'menu_data::y()'],['../structmap__data.html#a9a8a911e129ce4f955b6f66c0f9f25dc',1,'map_data::y()']]],
  ['year',['year',['../structtime__info__data.html#a9b23c77bd71d154d663750877835b09a',1,'time_info_data']]],
  ['yesvotes',['yesvotes',['../structnote__data.html#af04d42028bd94a7d75efa99b7ed67502',1,'note_data']]],
  ['ypos',['ypos',['../structspace__data.html#aea1ece0f7eef9e0b334a17ac9afbec14',1,'space_data']]]
];
