var searchData=
[
  ['pc_5fdata',['pc_data',['../structpc__data.html',1,'']]],
  ['planet_5fdata',['planet_data',['../structplanet__data.html',1,'']]],
  ['prototype_5froom',['prototype_room',['../structprototype__room.html',1,'']]]
];
