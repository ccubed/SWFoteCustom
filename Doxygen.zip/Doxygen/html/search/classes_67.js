var searchData=
[
  ['godlist_5fdata',['godlist_data',['../structgodlist__data.html',1,'']]],
  ['guard_5fdata',['guard_data',['../structguard__data.html',1,'']]]
];
