var searchData=
[
  ['editor_5fdata',['editor_data',['../structeditor__data.html',1,'']]],
  ['editor_5fline',['editor_line',['../structeditor__line.html',1,'']]],
  ['exit_5fdata',['exit_data',['../structexit__data.html',1,'']]],
  ['extra_5fdescr_5fdata',['extra_descr_data',['../structextra__descr__data.html',1,'']]],
  ['extracted_5fchar_5fdata',['extracted_char_data',['../structextracted__char__data.html',1,'']]]
];
