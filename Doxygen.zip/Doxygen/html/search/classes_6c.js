var searchData=
[
  ['lck_5fapp_5ftype',['lck_app_type',['../structlck__app__type.html',1,'']]],
  ['liq_5ftype',['liq_type',['../structliq__type.html',1,'']]]
];
