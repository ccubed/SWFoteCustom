var searchData=
[
  ['keb_2ec',['keb.c',['../keb_8c.html',1,'']]],
  ['keeper',['keeper',['../structshop__data.html#adb24e84b3c10a0d604419c6d0f76e670',1,'shop_data::keeper()'],['../structrepairshop__data.html#a4e124a41c81c44b311664001fe5c2b2a',1,'repairshop_data::keeper()']]],
  ['key',['key',['../structexit__data.html#a2ef6121c255eaad4461de21d1fa9376e',1,'exit_data::key()'],['../boards_8c.html#a3be731ad1786d63579ca93876bd08571',1,'KEY():&#160;boards.c'],['../clans_8c.html#a3be731ad1786d63579ca93876bd08571',1,'KEY():&#160;clans.c'],['../db_8c.html#a3be731ad1786d63579ca93876bd08571',1,'KEY():&#160;db.c'],['../finfo_8c.html#a3be731ad1786d63579ca93876bd08571',1,'KEY():&#160;finfo.c'],['../mud_8h.html#a3be731ad1786d63579ca93876bd08571',1,'KEY():&#160;mud.h'],['../pfiles_8c.html#a3be731ad1786d63579ca93876bd08571',1,'KEY():&#160;pfiles.c'],['../planets_8c.html#a3be731ad1786d63579ca93876bd08571',1,'KEY():&#160;planets.c'],['../save_8c.html#a3be731ad1786d63579ca93876bd08571',1,'KEY():&#160;save.c'],['../ships_8c.html#a3be731ad1786d63579ca93876bd08571',1,'KEY():&#160;ships.c'],['../slay_8c.html#a3be731ad1786d63579ca93876bd08571',1,'KEY():&#160;slay.c'],['../space_8c.html#a3be731ad1786d63579ca93876bd08571',1,'KEY():&#160;space.c'],['../space_8c.html#a3be731ad1786d63579ca93876bd08571',1,'KEY():&#160;space.c'],['../tables_8c.html#a3be731ad1786d63579ca93876bd08571',1,'KEY():&#160;tables.c']]],
  ['keypad',['keypad',['../structexit__data.html#a1039d60e7da9dfc63873d72ce5ba7c86',1,'exit_data']]],
  ['keys',['keys',['../structprototype__room.html#a099e8a27bae1da0be433081907ca579d',1,'prototype_room']]],
  ['keyword',['keyword',['../structhelp__data.html#add6106e94cd862ac363b11d1d9ecf9dd',1,'help_data::keyword()'],['../structextra__descr__data.html#a0173f2f9f733957566645b4a5b5b4d1e',1,'extra_descr_data::keyword()'],['../structexit__data.html#a4ba3907364f827dd950a4eea017e1705',1,'exit_data::keyword()']]],
  ['killed',['killed',['../structmob__index__data.html#ab123a004b1bafcf3d72f02eb96a445eb',1,'mob_index_data::killed()'],['../structpc__data.html#ad327e62f336072400d6fd7460c999bc8',1,'pc_data::killed()']]],
  ['killed_5fdata',['killed_data',['../structkilled__data.html',1,'killed_data'],['../mud_8h.html#aad6de34d42df993ecedf6db02642f155',1,'KILLED_DATA():&#160;mud.h']]],
  ['killer',['killer',['../structobj__data.html#ad011bce4557ed9cb6f18bd7d46798eeb',1,'obj_data']]],
  ['knownas',['knownas',['../structfellow__data.html#a63f4e318500844aae3aff2fe5404296a',1,'fellow_data']]],
  ['knows_5flanguage',['knows_language',['../act__comm_8c.html#af91d2727142d625b1116e0e703f1bbe5',1,'act_comm.c']]],
  ['knowsof',['knowsof',['../comm_8c.html#ad4e5f2209aa07385b954879bbed99a03',1,'comm.c']]]
];
