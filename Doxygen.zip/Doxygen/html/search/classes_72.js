var searchData=
[
  ['race_5ftype',['race_type',['../structrace__type.html',1,'']]],
  ['rel_5fdata',['rel_data',['../structrel__data.html',1,'']]],
  ['renumber_5farea',['renumber_area',['../structrenumber__area.html',1,'']]],
  ['renumber_5fdata',['renumber_data',['../structrenumber__data.html',1,'']]],
  ['repairshop_5fdata',['repairshop_data',['../structrepairshop__data.html',1,'']]],
  ['reset_5fdata',['reset_data',['../structreset__data.html',1,'']]],
  ['room_5findex_5fdata',['room_index_data',['../structroom__index__data.html',1,'']]]
];
