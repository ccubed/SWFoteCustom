var searchData=
[
  ['fellow_5fdata',['fellow_data',['../structfellow__data.html',1,'']]],
  ['fighting_5fdata',['fighting_data',['../structfighting__data.html',1,'']]],
  ['force_5fhelp_5fstruct',['force_help_struct',['../structforce__help__struct.html',1,'']]],
  ['force_5fskills_5fstruct',['force_skills_struct',['../structforce__skills__struct.html',1,'']]],
  ['frc_5fapp_5ftype',['frc_app_type',['../structfrc__app__type.html',1,'']]]
];
