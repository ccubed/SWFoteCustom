var searchData=
[
  ['killed_5fdata',['killed_data',['../structkilled__data.html',1,'']]]
];
