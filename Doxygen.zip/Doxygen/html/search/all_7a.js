var searchData=
[
  ['z',['z',['../structplanet__data.html#a0509161d73b5337a4bc557cf23a12e4c',1,'planet_data']]],
  ['zpos',['zpos',['../structspace__data.html#ae697a282e18025c9ecdf7d600a0c3df9',1,'space_data']]]
];
