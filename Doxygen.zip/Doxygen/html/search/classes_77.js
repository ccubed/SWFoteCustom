var searchData=
[
  ['weather_5fdata',['weather_data',['../structweather__data.html',1,'']]],
  ['who_5fdata',['who_data',['../structwho__data.html',1,'']]],
  ['wis_5fapp_5ftype',['wis_app_type',['../structwis__app__type.html',1,'']]],
  ['wizent',['wizent',['../structwizent.html',1,'']]]
];
