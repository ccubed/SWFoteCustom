var searchData=
[
  ['valid_5flangs',['VALID_LANGS',['../mud_8h.html#a87afeb91c0bd8f8b6d223f405fd3a1af',1,'mud.h']]],
  ['vip_5fbakura',['VIP_BAKURA',['../mud_8h.html#a4fdb244026953c7da14225bcdd60b76a',1,'mud.h']]],
  ['vip_5fcorellia',['VIP_CORELLIA',['../mud_8h.html#aa20092d41abda669435a7f764db06f67',1,'mud.h']]],
  ['vip_5fcoruscant',['VIP_CORUSCANT',['../mud_8h.html#a74be42bc3885a7f5eaa08480d4210a24',1,'mud.h']]],
  ['vip_5fendor',['VIP_ENDOR',['../mud_8h.html#a14a67ce9331eebd34b7b033cf2bf3e4c',1,'mud.h']]],
  ['vip_5fkashyyyk',['VIP_KASHYYYK',['../mud_8h.html#ab20185620125db2f784ab28c0a66d0b9',1,'mud.h']]],
  ['vip_5fmon_5fcalamari',['VIP_MON_CALAMARI',['../mud_8h.html#ab2fba15196ebadc6738b3ee7831f755e',1,'mud.h']]],
  ['vip_5fnal_5fhutta',['VIP_NAL_HUTTA',['../mud_8h.html#a2f880a6895e0ba349331c7fe4c4e5eef',1,'mud.h']]],
  ['vip_5ford_5fmantell',['VIP_ORD_MANTELL',['../mud_8h.html#a0d4655dc47c1048438e34237ace7fc70',1,'mud.h']]],
  ['vip_5ftatooine',['VIP_TATOOINE',['../mud_8h.html#a3ec4c1416bc2d310d6ed865ccbecb3c2',1,'mud.h']]],
  ['vip_5fyavin_5fiv',['VIP_YAVIN_IV',['../mud_8h.html#a23f34049c97030ec388009f90fc37453',1,'mud.h']]],
  ['vnum_5fdebit_5fcard',['VNUM_DEBIT_CARD',['../mud_8h.html#aa2f8aa3bc0f8d55f21606b989867de30',1,'mud.h']]],
  ['vote_5fclosed',['VOTE_CLOSED',['../boards_8c.html#a2e684a6540ebe3c1e716704231a94b37',1,'boards.c']]],
  ['vote_5fnone',['VOTE_NONE',['../boards_8c.html#ab442e7806646b8e894f62dc06d9ae199',1,'boards.c']]],
  ['vote_5fopen',['VOTE_OPEN',['../boards_8c.html#a1decd4957bcf38b231edb6b1cb94eac2',1,'boards.c']]]
];
