var searchData=
[
  ['senate_5fdata',['senate_data',['../structsenate__data.html',1,'']]],
  ['ship_5fdata',['ship_data',['../structship__data.html',1,'']]],
  ['ship_5fprototype_5fdata',['ship_prototype_data',['../structship__prototype__data.html',1,'']]],
  ['ship_5fprototypes_5fstruct',['ship_prototypes_struct',['../structship__prototypes__struct.html',1,'']]],
  ['shop_5fdata',['shop_data',['../structshop__data.html',1,'']]],
  ['skill_5ftype',['skill_type',['../structskill__type.html',1,'']]],
  ['slay_5fdata',['slay_data',['../structslay__data.html',1,'']]],
  ['smaug_5faffect',['smaug_affect',['../structsmaug__affect.html',1,'']]],
  ['social_5ftype',['social_type',['../structsocial__type.html',1,'']]],
  ['space_5fdata',['space_data',['../structspace__data.html',1,'']]],
  ['specfun_5flist',['specfun_list',['../structspecfun__list.html',1,'']]],
  ['str_5fapp_5ftype',['str_app_type',['../structstr__app__type.html',1,'']]],
  ['system_5fdata',['system_data',['../structsystem__data.html',1,'']]]
];
