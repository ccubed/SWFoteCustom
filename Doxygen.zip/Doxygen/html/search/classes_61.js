var searchData=
[
  ['act_5fprog_5fdata',['act_prog_data',['../structact__prog__data.html',1,'']]],
  ['affect_5fdata',['affect_data',['../structaffect__data.html',1,'']]],
  ['area_5fdata',['area_data',['../structarea__data.html',1,'']]],
  ['auction_5fdata',['auction_data',['../structauction__data.html',1,'']]]
];
