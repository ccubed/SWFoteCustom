var searchData=
[
  ['name',['NAME',['../comm_8c.html#a9966392e9cb9de4059fb3cae69b7adbe',1,'comm.c']]],
  ['nameban_5ffile',['NAMEBAN_FILE',['../mud_8h.html#a9f030c5f9ac8b2b9a251e55a51b7ff4b',1,'mud.h']]],
  ['no_5fpage',['NO_PAGE',['../mud_8h.html#add7c8e2d13a776f496d85ef9aa4fc0c5',1,'mud.h']]],
  ['no_5ftype',['NO_TYPE',['../mud_8h.html#a4159b53da9c6fe869517755161b5b3bc',1,'mud.h']]],
  ['not_5fauthed',['NOT_AUTHED',['../mud_8h.html#a9160fdc0a6ff00c92cc2cdd8ce0d5be9',1,'mud.h']]],
  ['not_5ffound',['NOT_FOUND',['../renumber_8c.html#a33bfc1f995233887a0414369c36936b8',1,'renumber.c']]],
  ['null_5ffile',['NULL_FILE',['../mud_8h.html#a0421dafd36b893a44765438025c265f7',1,'mud.h']]],
  ['nullstr',['NULLSTR',['../changes_8c.html#ad214bb1a742e27501b2a970ce8cb6c5f',1,'changes.c']]]
];
