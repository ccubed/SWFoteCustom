var searchData=
[
  ['death_5ftype',['death_type',['../structdeath__type.html',1,'']]],
  ['descriptor_5fdata',['descriptor_data',['../structdescriptor__data.html',1,'']]],
  ['dex_5fapp_5ftype',['dex_app_type',['../structdex__app__type.html',1,'']]]
];
