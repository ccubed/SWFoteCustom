var mccp_8h =
[
    [ "mccp_data", "structmccp__data.html", "structmccp__data" ],
    [ "COMPRESS_BUF_SIZE", "mccp_8h.html#a2b9c0b38c138ef28f97f63b27d3e0c05", null ],
    [ "TELOPT_COMPRESS2", "mccp_8h.html#a82ec84aae68874d8900245ab787a6d70", null ],
    [ "MCCP", "mccp_8h.html#ab46d089d1eefbfc218c5a01f26db216c", null ],
    [ "compressEnd", "mccp_8h.html#ae3beb3237cee602d342bc379ba3c8d41", null ],
    [ "compressStart", "mccp_8h.html#afcc394cbdbf91d7ca051a802a6f89ec5", null ],
    [ "start_compress2_str", "mccp_8h.html#ae0196b9994418b73d9fcc7cebf95ffe4", null ],
    [ "will_compress2_str", "mccp_8h.html#a506f01574d803256a18bad8a2453feee", null ]
];