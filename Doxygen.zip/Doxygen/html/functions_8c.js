var functions_8c =
[
    [ "chrmax", "functions_8c.html#a098eb513ed7339101c7b493f9b45e1e4", null ],
    [ "format_str", "functions_8c.html#a98a7da5f1747ee926e66c419bf859046", null ],
    [ "htmlcolor", "functions_8c.html#a37968cca6aa67c3ea2661ec1594a8ecc", null ],
    [ "remand", "functions_8c.html#a4218a97ca9cf0e2add6981b924a02001", null ],
    [ "rembg", "functions_8c.html#a517d88410110138fec48b47509cd0365", null ],
    [ "strip_color", "functions_8c.html#abb1cf0b1521418736b705c4e05beb41a", null ],
    [ "strlen_color", "functions_8c.html#af1f9403b67a744351ed09fcfe8d44df5", null ],
    [ "strlinwrp", "functions_8c.html#a1226b2ce95049835f3325e0e6e13d9ed", null ],
    [ "strrep", "functions_8c.html#a25756d3d0193da601dadc0b4239c7d7c", null ]
];