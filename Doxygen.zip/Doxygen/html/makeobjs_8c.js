var makeobjs_8c =
[
    [ "create_money", "makeobjs_8c.html#a7503e8f8a426c34365cb796a248aafbd", null ],
    [ "make_blood", "makeobjs_8c.html#aba4aec46682a0a10bface13dd25cb390", null ],
    [ "make_bloodstain", "makeobjs_8c.html#aff24f2a3ddc933d9ede3a6f01f43cd9c", null ],
    [ "make_corpse", "makeobjs_8c.html#a0cc1bb9001e8329dc8b3dc07451da81e", null ],
    [ "make_fire", "makeobjs_8c.html#a271cad3dd47356d2d5130bf2104d6eec", null ],
    [ "make_scraps", "makeobjs_8c.html#aa3416bb4924cf9d72ec623509ffa4a68", null ],
    [ "make_trap", "makeobjs_8c.html#a15ab9967cceb0331f06033150be46e95", null ]
];